package Main;

import ventanas.*;

public class MailServer {
    
    public static void main(String[] args) {
        Login login = new Login();
        login.setResizable(false);
        login.setVisible(true);
    }
}
